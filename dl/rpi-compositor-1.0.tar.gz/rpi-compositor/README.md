Rpi-compositor
==============
The Rpi Compositor is a qml wayland compositor with a RGBA background.

Build instruction
==============
